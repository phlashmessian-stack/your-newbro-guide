<?php
/**
 * NeuroBro — CloudPayments Webhook (Pay уведомление)
 *
 * Этот файл вызывается CloudPayments после успешной оплаты.
 * URL для настройки в ЛК CloudPayments:
 *   https://neuro-bro.ru/api/webhook.php
 *
 * ИНСТРУКЦИЯ:
 * 1. В ЛК CloudPayments → Настройки сайта → Уведомления
 * 2. Тип: Pay → URL: https://neuro-bro.ru/api/webhook.php
 * 3. Формат: CloudPayments
 * 4. Метод: POST
 */

header('Content-Type: application/json; charset=utf-8');

// ╔══════════════════════════════════════════════════════╗
// ║  ⬇️  ВСТАВЬТЕ СВОИ КЛЮЧИ SUPABASE И CP СЮДА  ⬇️     ║
// ╚══════════════════════════════════════════════════════╝
$CP_API_SECRET       = 'ВСТАВЬТЕ_API_SECRET';
$SUPABASE_URL        = 'https://YOUR_PROJECT.supabase.co';
$SUPABASE_SERVICE_KEY = 'ВСТАВЬТЕ_SERVICE_ROLE_KEY';
// ⚠️ Не коммитьте с реальными ключами!

// ═══ Проверка подписи CloudPayments ═══
function verifySignature($body, $signature, $apiSecret) {
    $expectedSignature = base64_encode(
        hash_hmac('sha256', $body, $apiSecret, true)
    );
    return hash_equals($expectedSignature, $signature);
}

$rawBody   = file_get_contents('php://input');
$signature = $_SERVER['HTTP_CONTENT_HMAC'] ?? '';

if (!$signature || !verifySignature($rawBody, $signature, $CP_API_SECRET)) {
    http_response_code(200); // CP ожидает 200 даже при ошибке
    echo json_encode(['code' => 13]); // 13 = отклонено
    exit;
}

// Парсим данные
$data = json_decode($rawBody, true);

$status    = $data['Status'] ?? '';
$amount    = (float)($data['Amount'] ?? 0);
$invoiceId = $data['InvoiceId'] ?? '';
$email     = $data['AccountId'] ?? '';
$jsonData  = json_decode($data['Data'] ?? '{}', true);

$userId    = $jsonData['user_id'] ?? '';
$productId = $jsonData['product_id'] ?? '';
$tokens    = (int)($jsonData['tokens'] ?? 0);
$type      = $jsonData['type'] ?? '';

// Проверяем статус
if ($status !== 'Completed') {
    echo json_encode(['code' => 0]); // Принято, но не обработано
    exit;
}

if (!$userId || !$productId) {
    error_log("NeuroBro Webhook: missing user_id or product_id in data");
    echo json_encode(['code' => 0]);
    exit;
}

// ═══ Начисление токенов через Supabase RPC ═══
if ($type === 'pack' && $tokens > 0) {
    $result = supabaseRPC('add_tokens', [
        '_user_id'    => $userId,
        '_amount'     => $tokens,
        '_type'       => 'purchase',
        '_description' => "Покупка пакета: $productId ({$amount}₽)",
    ]);

    if (!$result['success']) {
        error_log("NeuroBro Webhook: failed to add tokens - " . $result['error']);
    }
}

// ═══ Активация подписки ═══
if ($type === 'subscription') {
    $subName = str_replace('sub_', '', $productId); // lite, pro, ultra
    $result = supabaseQuery(
        'profiles',
        'PATCH',
        ['subscription' => $subName],
        "id=eq.$userId"
    );

    if (!$result['success']) {
        error_log("NeuroBro Webhook: failed to activate subscription - " . $result['error']);
    }
}

// Логируем
error_log("NeuroBro Payment OK: user=$userId product=$productId amount={$amount}₽ tokens=$tokens");

// CloudPayments ожидает {"code": 0} = успех
echo json_encode(['code' => 0]);

// ═══ Supabase helpers ═══

function supabaseRPC($functionName, $params) {
    global $SUPABASE_URL, $SUPABASE_SERVICE_KEY;

    $ch = curl_init("$SUPABASE_URL/rest/v1/rpc/$functionName");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($params),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'apikey: ' . $SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . $SUPABASE_SERVICE_KEY,
            'Prefer: return=minimal',
        ],
        CURLOPT_TIMEOUT => 10,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'success' => ($httpCode >= 200 && $httpCode < 300),
        'error'   => $httpCode >= 300 ? "HTTP $httpCode: $response" : null,
    ];
}

function supabaseQuery($table, $method, $body, $filter = '') {
    global $SUPABASE_URL, $SUPABASE_SERVICE_KEY;

    $url = "$SUPABASE_URL/rest/v1/$table" . ($filter ? "?$filter" : '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'apikey: ' . $SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . $SUPABASE_SERVICE_KEY,
            'Prefer: return=minimal',
        ],
        CURLOPT_TIMEOUT => 10,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'success' => ($httpCode >= 200 && $httpCode < 300),
        'error'   => $httpCode >= 300 ? "HTTP $httpCode: $response" : null,
    ];
}
