<?php
/**
 * NeuroBro — CloudPayments: создание платёжной сессии
 *
 * ИНСТРУКЦИЯ:
 * 1. Зарегистрируйтесь на https://cloudpayments.ru
 * 2. Получите Public ID и API Secret в личном кабинете
 * 3. Вставьте их ниже
 * 4. Загрузите этот файл на хостинг в /api/
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error' => 'Only POST']); exit; }

// ╔══════════════════════════════════════════════════╗
// ║  ⬇️  ВСТАВЬТЕ СВОИ КЛЮЧИ CLOUDPAYMENTS СЮДА  ⬇️  ║
// ╚══════════════════════════════════════════════════╝
$CP_PUBLIC_ID  = 'pk_ВСТАВЬТЕ_PUBLIC_ID';
$CP_API_SECRET = 'ВСТАВЬТЕ_API_SECRET';
// ⚠️ Не коммитьте этот файл в git с реальными ключами!

// ═══ Тарифы и пакеты ═══
$products = [
    // Пакеты токенов
    'pack_small'  => ['name' => '5,000 токенов',  'amount' => 99,   'tokens' => 5000,  'type' => 'pack'],
    'pack_medium' => ['name' => '20,000 токенов', 'amount' => 299,  'tokens' => 20000, 'type' => 'pack'],
    'pack_large'  => ['name' => '50,000 токенов', 'amount' => 699,  'tokens' => 50000, 'type' => 'pack'],
    // Подписки
    'sub_lite'    => ['name' => 'Подписка Lite',   'amount' => 299,  'tokens' => 0, 'type' => 'subscription'],
    'sub_pro'     => ['name' => 'Подписка Pro',    'amount' => 599,  'tokens' => 0, 'type' => 'subscription'],
    'sub_ultra'   => ['name' => 'Подписка Ultra',  'amount' => 999,  'tokens' => 0, 'type' => 'subscription'],
];

$input = json_decode(file_get_contents('php://input'), true);
$productId = $input['product_id'] ?? '';
$userId    = $input['user_id'] ?? '';
$userEmail = $input['email'] ?? '';

if (!$productId || !$userId || !$userEmail) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing product_id, user_id or email']);
    exit;
}

if (!isset($products[$productId])) {
    http_response_code(400);
    echo json_encode(['error' => 'Unknown product: ' . $productId]);
    exit;
}

$product = $products[$productId];

// Генерируем данные для виджета CloudPayments (фронтенд сам откроет виджет)
$orderData = [
    'publicId'    => $CP_PUBLIC_ID,
    'description' => $product['name'] . ' — NeuroBro',
    'amount'      => $product['amount'],
    'currency'    => 'RUB',
    'accountId'   => $userEmail,
    'invoiceId'   => uniqid('nb_', true),
    'data'        => [
        'user_id'    => $userId,
        'product_id' => $productId,
        'tokens'     => $product['tokens'],
        'type'       => $product['type'],
    ],
];

// Для подписок — добавляем рекуррентный параметр
if ($product['type'] === 'subscription') {
    $orderData['data']['cloudPayments'] = [
        'recurrent' => [
            'interval'   => 'Month',
            'period'     => 1,
            'amount'     => $product['amount'],
            'currency'   => 'RUB',
        ],
    ];
}

echo json_encode(['success' => true, 'order' => $orderData]);
