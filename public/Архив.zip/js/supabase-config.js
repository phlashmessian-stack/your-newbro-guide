// Supabase client — loaded via CDN in HTML
const SUPABASE_URL = 'https://qgnolzkwjanymtyirvbv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFnbm9semt3amFueW10eWlydmJ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA3NTAwMTEsImV4cCI6MjA4NjMyNjAxMX0.v4xfcnLmHIxI9NGFbPXyOv2t-aiKMceN-ewD-sd9UeA';

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Toast system
const toastContainer = document.createElement('div');
toastContainer.className = 'toast-container';
document.body.appendChild(toastContainer);

function showToast(message, type = 'info') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = message;
  toastContainer.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3000);
}

// Generate password
function generatePassword() {
  const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%';
  let pwd = '';
  for (let i = 0; i < 12; i++) pwd += chars[Math.floor(Math.random() * chars.length)];
  return pwd;
}
