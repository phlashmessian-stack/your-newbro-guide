let adminUser=null,adminProfile=null,users=[],adminTab='overview';
const tabs=[{id:'overview',icon:'📊',label:'Обзор'},{id:'users',icon:'👥',label:'Пользователи'},{id:'transactions',icon:'📈',label:'Транзакции'},{id:'broadcast',icon:'📧',label:'Рассылка'},{id:'settings',icon:'⚙️',label:'Настройки'}];

(async()=>{
  const u=await getUser();if(!u){window.location.href='/';return}
  adminUser=u;
  const adm=await checkAdmin(u.id);if(!adm){window.location.href='/dashboard.html';return}
  adminProfile=await getProfile(u.id);
  await fetchUsers();renderNav();renderTab();
  sb.auth.onAuthStateChange((_,s)=>{if(!s)window.location.href='/'});
})();

function renderNav(){
  const mk=t=>`<button class="admin-nav-item ${adminTab===t.id?'active':''}" onclick="adminTab='${t.id}';renderNav();renderTab()">${t.icon} ${t.label}</button>`;
  document.getElementById('sidebarNav').innerHTML=tabs.map(mk).join('');
  document.getElementById('mobileNav').innerHTML=tabs.map(t=>`<button class="admin-mobile-item ${adminTab===t.id?'active':''}" onclick="adminTab='${t.id}';renderNav();renderTab()">${t.icon}<br><span style="font-size:0.5rem">${t.label}</span></button>`).join('');
}

async function fetchUsers(){
  const{data}=await sb.from('profiles').select('id,email,tokens_balance,subscription,referral_code,created_at').order('created_at',{ascending:false});
  if(data)users=data;
}

function esc(s){const d=document.createElement('div');d.textContent=s;return d.innerHTML}

function renderTab(){
  const m=document.getElementById('adminMain');
  if(adminTab==='overview')renderOverview(m);
  else if(adminTab==='users')renderUsers(m);
  else if(adminTab==='transactions')renderTransactions(m);
  else if(adminTab==='broadcast')renderBroadcast(m);
  else if(adminTab==='settings')renderSettings(m);
}

function renderOverview(m){
  const total=users.length,today=users.filter(u=>new Date(u.created_at).toDateString()===new Date().toDateString()).length;
  const withSub=users.filter(u=>u.subscription).length,totalTok=users.reduce((s,u)=>s+u.tokens_balance,0);
  m.innerHTML=`<div class="space-y-6">
    <div class="flex items-center justify-between"><h1 style="font-size:1.5rem;font-weight:700">Обзор</h1><button class="btn-secondary btn-sm" onclick="fetchUsers().then(()=>renderTab())">🔄 Обновить</button></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:0.75rem">
      <div class="card stat-card"><p class="stat-label">👥 Всего</p><p class="stat-value">${total}</p></div>
      <div class="card stat-card"><p class="stat-label">✅ Сегодня</p><p class="stat-value">${today}</p></div>
      <div class="card stat-card"><p class="stat-label">📋 С подпиской</p><p class="stat-value">${withSub}</p></div>
      <div class="card stat-card"><p class="stat-label">💰 Токенов</p><p class="stat-value">${totalTok.toLocaleString()}</p></div>
    </div>
    <div class="card" style="padding:1rem"><p style="font-weight:600;margin-bottom:0.75rem">⚡ Быстрые действия</p>
      <div class="flex flex-wrap gap-2">
        <button class="btn-secondary btn-sm" onclick="adminTab='broadcast';renderNav();renderTab()">📧 Рассылка</button>
        <button class="btn-secondary btn-sm" onclick="adminTab='transactions';renderNav();renderTab()">📈 Транзакции</button>
        <button class="btn-secondary btn-sm" onclick="adminTab='settings';renderNav();renderTab()">⚙️ Настройки</button>
      </div>
    </div>
    <div class="card"><div style="padding:1rem;border-bottom:1px solid rgba(42,41,53,0.2)"><p style="font-weight:600">Последние регистрации</p></div>
      <div style="padding:1rem" class="space-y-2">${users.slice(0,8).map(u=>`<div class="flex items-center justify-between text-sm" style="padding:0.5rem 0;border-bottom:1px solid rgba(42,41,53,0.2)"><div style="min-width:0"><span class="truncate" style="display:block;max-width:200px">${esc(u.email)}</span><span style="font-size:0.625rem;color:var(--muted)">${new Date(u.created_at).toLocaleString('ru-RU')}</span></div><div class="flex items-center gap-3 shrink-0"><span class="font-mono text-xs text-muted">${u.tokens_balance.toLocaleString()}</span>${u.subscription?`<span style="padding:0.125rem 0.5rem;border-radius:999px;font-size:0.75rem;background:rgba(34,197,94,0.1);color:var(--neon-green)">${u.subscription}</span>`:''}</div></div>`).join('')}</div>
    </div>
  </div>`;
}

function renderUsers(m){
  m.innerHTML=`<div class="space-y-4">
    <div class="flex items-center justify-between"><h1 style="font-size:1.5rem;font-weight:700">Пользователи (${users.length})</h1><button class="btn-secondary btn-sm" onclick="fetchUsers().then(()=>renderTab())">🔄</button></div>
    <input class="input" placeholder="Поиск по email..." id="userSearch" oninput="filterUsers()">
    <div id="usersList" class="space-y-2"></div>
  </div>`;
  filterUsers();
}

function filterUsers(){
  const q=(document.getElementById('userSearch')?.value||'').toLowerCase();
  const f=users.filter(u=>u.email.toLowerCase().includes(q)||u.referral_code.toLowerCase().includes(q));
  document.getElementById('usersList').innerHTML=f.map(u=>`
    <div class="card user-card">
      <div class="flex items-center justify-between"><div style="min-width:0"><p class="text-sm font-bold truncate" style="max-width:250px">${esc(u.email)}</p><p class="text-xs text-muted">Реф: ${u.referral_code} · ${new Date(u.created_at).toLocaleDateString('ru-RU')}</p></div><div style="text-align:right;flex-shrink:0"><p class="font-mono text-sm">${u.tokens_balance.toLocaleString()} 💎</p><p class="text-xs text-muted">${u.subscription?'📋 '+u.subscription:'Нет подписки'}</p></div></div>
      <div class="user-actions">
        <button class="btn-secondary btn-sm" onclick="adminAddTok('${u.id}',100)">+100</button>
        <button class="btn-secondary btn-sm" onclick="adminAddTok('${u.id}',1000)">+1K</button>
        <button class="btn-secondary btn-sm" onclick="adminAddTok('${u.id}',10000)">+10K</button>
        ${u.subscription?`<button class="btn-secondary btn-sm btn-danger" onclick="adminSetSub('${u.id}',null)">Снять подписку</button>`:`<button class="btn-secondary btn-sm" onclick="adminSetSub('${u.id}','lite')">⭐ Lite</button><button class="btn-secondary btn-sm" onclick="adminSetSub('${u.id}','pro')">👑 Pro</button><button class="btn-secondary btn-sm" onclick="adminSetSub('${u.id}','ultra')">💎 Ultra</button>`}
        <button class="btn-secondary btn-sm btn-danger" onclick="adminReset('${u.id}')">🚫 Обнулить</button>
      </div>
    </div>
  `).join('');
}

async function adminAddTok(uid,amt){await sb.rpc('add_tokens',{_user_id:uid,_amount:amt,_type:'bonus',_description:'Админ +'+amt});await fetchUsers();renderTab();showToast('+'+amt+' токенов начислено','success')}
async function adminSetSub(uid,sub){await sb.from('profiles').update({subscription:sub}).eq('id',uid);await fetchUsers();renderTab();showToast(sub?'Подписка '+sub+' установлена':'Подписка снята','success')}
async function adminReset(uid){await sb.from('profiles').update({tokens_balance:0}).eq('id',uid);await fetchUsers();renderTab();showToast('Баланс обнулён','success')}

async function renderTransactions(m){
  m.innerHTML='<p class="text-muted text-center">Загрузка...</p>';
  const{data}=await sb.from('token_transactions').select('*,profiles:user_id(email)').order('created_at',{ascending:false}).limit(200);
  const txs=data||[];
  const spent=txs.filter(t=>t.amount<0).reduce((s,t)=>s+t.amount,0);
  const added=txs.filter(t=>t.amount>0).reduce((s,t)=>s+t.amount,0);
  m.innerHTML=`<div class="space-y-4">
    <h1 style="font-size:1.5rem;font-weight:700">📊 Транзакции</h1>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.75rem">
      <div class="card" style="padding:1rem"><p class="text-xs text-muted">⬆️ Начислено</p><p class="font-mono font-bold text-green" style="font-size:1.125rem">+${added.toLocaleString()}</p></div>
      <div class="card" style="padding:1rem"><p class="text-xs text-muted">⬇️ Потрачено</p><p class="font-mono font-bold text-pink" style="font-size:1.125rem">${spent.toLocaleString()}</p></div>
    </div>
    <div class="space-y-1" style="max-height:500px;overflow-y:auto">${txs.map(t=>`<div class="card flex items-center justify-between text-sm" style="padding:0.75rem 1rem"><div style="min-width:0;flex:1"><p class="truncate font-bold">${esc(t.profiles?.email||t.user_id.slice(0,8))}</p><p class="text-xs text-muted truncate">${esc(t.description||'')}</p><p style="font-size:0.625rem;color:var(--muted)">${new Date(t.created_at).toLocaleString('ru-RU')} · ${t.type}</p></div><span class="font-mono font-bold shrink-0" style="margin-left:0.75rem;color:${t.amount>0?'var(--neon-green)':'var(--neon-pink)'}">${t.amount>0?'+':''}${t.amount.toLocaleString()}</span></div>`).join('')}
    ${txs.length===0?'<p class="text-center text-muted" style="padding:2rem">Транзакций нет</p>':''}
    </div>
  </div>`;
}

function renderBroadcast(m){
  m.innerHTML=`<div class="space-y-6">
    <h1 style="font-size:1.5rem;font-weight:700">📧 Рассылка</h1>
    <div><p class="text-sm font-bold text-muted" style="margin-bottom:0.5rem">Шаблоны</p><div class="flex flex-wrap gap-2">
      <button class="btn-secondary btn-sm" onclick="document.getElementById('bcSubject').value='Новая функция в NeuroBro!'">🎉 Новая функция</button>
      <button class="btn-secondary btn-sm" onclick="document.getElementById('bcSubject').value='Бонусные токены для вас! 🎁'">🎁 Бонусные токены</button>
      <button class="btn-secondary btn-sm" onclick="document.getElementById('bcSubject').value='Специальная акция в NeuroBro! 📢'">📢 Акция</button>
    </div></div>
    <div><p class="text-sm font-bold text-muted" style="margin-bottom:0.5rem">Получатели</p><div class="flex flex-wrap gap-2">
      <button class="btn-secondary btn-sm" id="fAll" onclick="setBcFilter('all')" style="border-color:rgba(124,58,237,0.5);color:var(--primary)">👥 Все</button>
      <button class="btn-secondary btn-sm" id="fSub" onclick="setBcFilter('with_subscription')">📋 С подпиской</button>
      <button class="btn-secondary btn-sm" id="fNoSub" onclick="setBcFilter('without_subscription')">🚫 Без подписки</button>
    </div></div>
    <div><label class="text-sm text-muted" style="margin-bottom:0.25rem;display:block">Тема письма</label><input class="input" id="bcSubject" placeholder="Тема..."></div>
    <div><label class="text-sm text-muted" style="margin-bottom:0.25rem;display:block">HTML тело письма</label><textarea class="input font-mono" id="bcHtml" rows="10" placeholder="<div>Ваше письмо...</div>" style="font-size:0.75rem"></textarea></div>
    <button class="btn-primary" id="bcSendBtn" onclick="sendBroadcast()">📨 Отправить рассылку</button>
    <div id="bcResult"></div>
  </div>`;
}

let bcFilter='all';
function setBcFilter(f){
  bcFilter=f;
  ['fAll','fSub','fNoSub'].forEach(id=>{const el=document.getElementById(id);if(el){el.style.borderColor=el.id==='f'+{all:'All',with_subscription:'Sub',without_subscription:'NoSub'}[f]?'rgba(124,58,237,0.5)':'';el.style.color=el.id==='f'+{all:'All',with_subscription:'Sub',without_subscription:'NoSub'}[f]?'var(--primary)':''}});
}

async function sendBroadcast(){
  const subject=document.getElementById('bcSubject').value.trim();
  const html=document.getElementById('bcHtml').value.trim();
  if(!subject||!html){showToast('Заполните тему и HTML','error');return}
  const btn=document.getElementById('bcSendBtn');btn.disabled=true;btn.innerHTML='<span class="spinner"></span> Отправка...';
  try{
    const{data,error}=await sb.functions.invoke('send-broadcast',{body:{subject,html,filter:bcFilter}});
    if(error)throw error;
    document.getElementById('bcResult').innerHTML=`<div class="card" style="padding:1rem"><p class="text-sm">✅ Отправлено: <strong>${data.sent}</strong> из <strong>${data.total}</strong></p></div>`;
    showToast('Рассылка отправлена!','success');
  }catch(e){showToast('Ошибка: '+e.message,'error')}
  btn.disabled=false;btn.textContent='📨 Отправить рассылку';
}

// Settings
const settingGroups=[
  {title:'🎁 Бонусы',fields:[{key:'daily_bonus_amount',label:'Ежедневный бонус',type:'number',suffix:'токенов',def:10},{key:'referral_bonus_amount',label:'Реферальный бонус',type:'number',suffix:'токенов',def:3000},{key:'registration_bonus',label:'Бонус за регистрацию',type:'number',suffix:'токенов',def:100}]},
  {title:'⚡ Стоимость генерации',fields:[{key:'chat_token_cost',label:'Чат-сообщение',type:'number',suffix:'токенов',def:1},{key:'image_token_cost',label:'Картинка',type:'number',suffix:'токенов',def:5},{key:'video_token_cost',label:'Видео',type:'number',suffix:'токенов',def:20}]},
  {title:'📋 Подписки',fields:[{key:'sub_lite_price',label:'Lite',type:'number',suffix:'₽/мес',def:299},{key:'sub_pro_price',label:'Pro',type:'number',suffix:'₽/мес',def:599},{key:'sub_ultra_price',label:'Ultra',type:'number',suffix:'₽/мес',def:999}]},
  {title:'💎 Пакеты токенов',fields:[{key:'pack_small_tokens',label:'Пакет S — токены',type:'number',suffix:'токенов',def:5000},{key:'pack_small_price',label:'Пакет S — цена',type:'number',suffix:'₽',def:99},{key:'pack_medium_tokens',label:'Пакет M — токены',type:'number',suffix:'токенов',def:20000},{key:'pack_medium_price',label:'Пакет M — цена',type:'number',suffix:'₽',def:299},{key:'pack_large_tokens',label:'Пакет L — токены',type:'number',suffix:'токенов',def:50000},{key:'pack_large_price',label:'Пакет L — цена',type:'number',suffix:'₽',def:699}]},
  {title:'🔧 Режимы',fields:[{key:'maintenance_mode',label:'Режим обслуживания',type:'boolean',def:false},{key:'demo_mode',label:'Демо-режим',type:'boolean',def:true}]}
];
const allFields=settingGroups.flatMap(g=>g.fields);
let settingsData={};

async function renderSettings(m){
  m.innerHTML='<p class="text-muted text-center">Загрузка настроек...</p>';
  allFields.forEach(f=>settingsData[f.key]=f.def);
  const{data}=await sb.from('site_settings').select('key,value').limit(50);
  if(data)data.forEach(r=>{const f=allFields.find(f=>f.key===r.key);if(f){settingsData[r.key]=f.type==='boolean'?r.value==='true':Number(r.value)||0}});
  m.innerHTML=`<div class="space-y-6">
    <div class="flex items-center justify-between"><h1 style="font-size:1.5rem;font-weight:700">⚙️ Настройки</h1><button class="btn-primary btn-sm" id="saveSettingsBtn" onclick="saveSettings()">💾 Сохранить</button></div>
    ${settingGroups.map(g=>`<div class="setting-group"><h3>${g.title}</h3>${g.fields.map(f=>`
      <div class="card setting-row">
        <div class="setting-label"><p>${f.label}</p></div>
        ${f.type==='boolean'?`<button class="toggle ${settingsData[f.key]?'on':'off'}" onclick="settingsData['${f.key}']=!settingsData['${f.key}'];this.className='toggle '+(settingsData['${f.key}']?'on':'off')"><div class="toggle-knob"></div></button>`
        :`<div class="flex items-center gap-2 shrink-0"><input type="number" class="input setting-input" value="${settingsData[f.key]}" onchange="settingsData['${f.key}']=Number(this.value)">${f.suffix?`<span class="setting-suffix">${f.suffix}</span>`:''}</div>`}
      </div>`).join('')}</div>`).join('')}
  </div>`;
}

async function saveSettings(){
  const btn=document.getElementById('saveSettingsBtn');btn.disabled=true;btn.innerHTML='<span class="spinner"></span>';
  for(const f of allFields){await sb.from('site_settings').upsert({key:f.key,value:String(settingsData[f.key])},{onConflict:'key'})}
  showToast('✅ Настройки сохранены','success');
  btn.disabled=false;btn.textContent='💾 Сохранить';
}
